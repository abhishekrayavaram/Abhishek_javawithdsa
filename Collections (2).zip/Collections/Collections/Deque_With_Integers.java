package collections;

import java.util.Deque;
import java.util.LinkedList;

 public class Deque_With_Integers {

    public static void main(String[] args) {
        // Creating Deque using the ArrayDeque class
        Deque<Integer> numbers = new LinkedList<>();

        // add elements to the Deque
        numbers.add(10);
        numbers.addLast(25);
        numbers.addFirst(3);
        System.out.println("Deque: " + numbers);

        // Access elements of the Deque
        int firstElement = numbers.peekFirst();
        System.out.println("First Element: " + firstElement);

        int lastElement = numbers.peekLast();
        System.out.println("Last Element: " + lastElement);
        numbers.add(102);
       
       System.out.println("After Adding Element By Not Mentioning Last Or First"+numbers);

        
        // Remove elements from the Deque
        int removedNumber1 = numbers.pollFirst();
        System.out.println("Removed First Element: " + removedNumber1);

        int removedNumber2 = numbers.pollLast();
        System.out.println("Removed Last Element: " + removedNumber2);

        System.out.println("Updated Deque: " + numbers);
        
        
    }
}

