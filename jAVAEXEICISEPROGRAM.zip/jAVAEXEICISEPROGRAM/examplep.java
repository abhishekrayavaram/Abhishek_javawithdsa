package jAVAEXEICISEPROGRAM;

import JavaPracticeProgram.andhra;
import JavaPracticeProgram.axis;
import JavaPracticeProgram.kotak;
import JavaPracticeProgram.rbi;

public class examplep {

	public static void main(String[] args) {
		rbi obj;
		obj=new andhra();
		System.out.println("andhra rateofinterest:"+obj.getrateofinterest());
		obj=new axis();
		System.out.println("axis rateofinterest:"+obj.getrateofinterest());
		obj=new kotak();
		System.out.println("kotak rateofinterest:"+obj.getrateofinterest());
	}

}
