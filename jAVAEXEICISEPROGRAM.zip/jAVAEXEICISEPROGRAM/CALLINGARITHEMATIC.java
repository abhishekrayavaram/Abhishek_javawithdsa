package jAVAEXEICISEPROGRAM;

import JavaPracticeProgram.ARITHEMATICOPERATION1;

public class CALLINGARITHEMATIC {

	public static void main(String[] args) {
	ARITHEMATICOPERATION1 obj=new ARITHEMATICOPERATION1();	// TODO Auto-generated method stub
     System.out.println(obj.sum(20,25));
	}

}
