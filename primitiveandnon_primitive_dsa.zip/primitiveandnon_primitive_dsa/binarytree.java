package primitiveandnon_primitive_dsa;

class node{
	int data;
	node left,right;
	node(int value){
		data = value;
		left = right = null;
	}
}

public class binarytree {
     node root;
     void inorder(node node) {
    	 if(node != null) {
    		 inorder(node.left);
    		 System.out.print(node.data+" ");
    		 inorder(node.right);
    	 }
     }
     void preorder(node node) {
    	 if(node != null) {
    		 System.out.print(node.data+" ");
    		 preorder(node.left);
    		 preorder(node.right);
    	 }
     }
     void postorder(node node) {
    	 if(node != null) {
    		 postorder(node.left);
    		 postorder(node.right);
    		 System.out.print(node.data+"");
    	 }
     }
	public static void main(String[] args) {
		binarytree tree = new binarytree();
		tree.root=new node(1);
		tree.root.left=new node(2);
		tree.root.right=new node(3);
		tree.root.left.left=new node(4);
		tree.root.left.right=new node(5);
		System.out.println("in-order");
		tree.inorder(tree.root);
		System.out.println("\n pre_order");
		tree.preorder(tree.root);
		System.out.println("\n post_order:");
		tree.postorder(tree.root);
		// TODO Auto-generated method stub

	}

}
