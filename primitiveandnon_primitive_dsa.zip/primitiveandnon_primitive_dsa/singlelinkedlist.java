package primitiveandnon_primitive_dsa;

public class singlelinkedlist {
	static class node{
		int data;
		node next;
		node(int data){
			this.data =data;
			this.next=null;
		}
	}
	node head =null;
	public void insert(int data) {
		node newnode =new node(data);
		if(head ==null) {
			head =newnode;
		}else {
			node temp =head;
		
			while(temp.next !=null) {
				temp = temp.next;
				
			}
			temp.next = newnode;
			
		}
	}
	public void delete(int value) {
		if(head == null) {
			System.out.println("list is empty!");
			return;
		}
		if(head.data == value) {
			head = head.next;
			return;
		}
		node current = head;
		node previous = null;
		while(current != null && current.data != value){
			previous = current;
			current =current.next;
		}
		if(current == null) {
			System.out.println("value not found!");
			return;
		}
		previous.next = current.next;
	}
	public boolean search(int key) {
		node temp = head;
		while(temp != null) {
			if(temp.data == key) {
				return true;
			}
			temp = temp.next;
		}
		return false;
	}
	public void display() {
		if(head == null) {
			System.out.println("list is empty:");
			return;
		}
		node temp = head;
		System.out.print("linked list: ");
		while(temp != null) {
			System.out.print(temp.data+" -> ");
			temp = temp.next;
		}
		System.out.println("null");
	}
public static void main(String[] args) {
	singlelinkedlist list = new singlelinkedlist();
	list.insert(10);
	list.insert(20);
	list.insert(30);
	list.insert(40);
	list.display();
	System.out.println("searching 30:"+list.search(30));
	list.delete(20);
	list.display();
	list.delete(10);
	list.display();
	list.insert(40);
	list.display();
	System.out.println("searching 30: "+list.search(30));
	list.delete(20);
	list.display();
	list.delete(10);
	list.display();
}
}
