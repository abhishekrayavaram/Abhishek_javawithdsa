package primitiveandnon_primitive_dsa;

public class doublelinkedlist {
	static class node {
		int data;
		node prev;
		node next;
		node(int data){
			this.data = data;
		}
	}
	node head =null;
	node tail = null;
	public void insert(int data) {
		node newnode = new node(data);
		if(head == null) {
			head = tail = newnode;
		}else {
			tail.next = newnode;
			newnode.prev = tail;
			tail = newnode;
		}
	}
	public void delete(int value) {
		if(head == null) {
			System.out.println("list is empty!");
			return;
		}
		node current = head;
		while(current != null && current.data != value) {
			current = current.next;
		}
		if(current == null) {
			System.out.println("value not found!");
			return;
		}
		if(current == head) {
			head = head.next;
			if(head != null) head.prev = null;
		}
		else if(current == tail) {
			tail = tail.prev;
			tail.next = null;
		}
		else {
			current.prev.next = current.next;
			current.next.prev = current.prev;
		}
	}
public boolean search(int key) {
	node temp = head;
	while(temp != null) {
		if(temp.data == key)return true;
		temp = temp.next;
	}
	return false;
}
public void displayforward() {
	node temp = head;
	System.out.print("forward: ");
	while(temp != null) {
		System.out.print(temp.data+"->");
		temp = temp.next;
	}
	System.out.println("null");
}
public void displaybackward() {
    node temp = tail;
    System.out.print("backward: ");
    while(temp != null) {
        System.out.print(temp.data + " -> ");
        temp = temp.prev;
    }
    System.out.println("null");
}

public static void main(String[] args) {
	doublelinkedlist dll = new doublelinkedlist();
	dll.insert(10);
	dll.insert(20);
	dll.insert(30);
	dll.insert(40);
	dll.displayforward();
	dll.displaybackward();
	System.out.println("searching 30: "+dll.search(30));
	System.out.println("searching 50: "+dll.search(50));
	dll.delete(20);
	dll.displayforward();
	System.out.println("searching 30: "+dll.search(30));
	System.out.println("searching 50: "+dll.search(50));
	dll.delete(20);
	dll.displayforward();
	dll.delete(10);
	dll.displayforward();
	dll.delete(40);
	dll.displayforward();
}
}
