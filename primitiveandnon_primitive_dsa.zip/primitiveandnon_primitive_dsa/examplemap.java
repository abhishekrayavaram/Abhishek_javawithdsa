package primitiveandnon_primitive_dsa;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class examplemap {

	public static void main(String[] args) {
		Map<String, Integer> map =new HashMap<>();
		map.put("apple",3);
		map.put("banana",5);
		map.put("orange",2);
		System.out.println("apple count:"+map.get("apple"));
		for(Entry<String, Integer> entry:map.entrySet()) {
			System.out.println(entry.getKey()+"=>"+entry.getValue());
		}
		if(map.containsKey("banana")) {
			System.out.println("banana exists");
		}map.remove("orange");
		System.out.println("size:"+map.size());
		// TODO Auto-generated method stub

	}

}
