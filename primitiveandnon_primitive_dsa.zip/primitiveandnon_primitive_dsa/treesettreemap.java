package primitiveandnon_primitive_dsa;

import java.util.TreeMap;
import java.util.TreeSet;

class treesettreemap{
    public static void main(String[] args)
    {
        TreeSet<Integer> treeset = new TreeSet<>();
        treeset.add(3);
        treeset.add(4);
        treeset.add(3);
        treeset.add(5);
        System.out.println("Before Three Years Your Age Is:");
        for(Integer number:treeset) {
        System.out.println(" Your Age Is :   "+number);	
        }
        System.out.println("After Three Years Your Age Is:");
        for(Integer number:treeset) {
        	number=number+3;
        System.out.println(" Your Age Is :   "+number);	
        }
  
        TreeMap<Integer, Integer> treemap = new TreeMap<>();
        treemap.put(2, 4);
        treemap.put(3, 5);
        treemap.put(4, 5);
        treemap.put(2, 3);
        System.out.print(treeset);
        System.out.println(treemap);
    }
}


