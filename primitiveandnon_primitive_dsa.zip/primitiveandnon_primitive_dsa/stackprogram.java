package primitiveandnon_primitive_dsa;

public class stackprogram {
	private int maxsize;
	private int[] stackArray;
	private int top;
	public stackprogram(int size) {
		maxsize = size;
		stackArray = new int[maxsize];
		top = -1;
	}
	public void push(int value) {
		if(top >= maxsize -1) {
			System.out.println("stack overflow!");
			return;
		}
		stackArray[++top] = value;
		System.out.println("pushed: "+value);
	}
	public int pop() {
		if(isempty()) {
			System.out.println("stack underflow!");
			return-1;
		}
		return stackArray[top--];
	}
	public int peek() {
		if (isempty()) {
			System.out.println("stack is empty!");
			return -1;
		}
		return stackArray[top];
	}
	public boolean isempty() {
		return top == -1;
	}
	public void display() {
		System.out.print("stack: ");
		for(int i=0;i<=top;i++) {
			System.out.print(stackArray[i]+" ");
		}
		System.out.println();
	}
	public static void main(String[] args) {
		stackprogram stack =new stackprogram(5);
		stack.push(10);
		stack.push(20);
		stack.push(30);
		stack.display();
		System.out.println("peek: "+stack.peek());
		System.out.println("popped: "+stack.pop());
		stack.display();
		System.out.println("is empty?" +stack.isempty());
	}
  

}
