package Java;

public class Datatypes {
	public static void main(String[] args) {
		String x = "Hello World";     //STRING Variable Declaration
		char y = 'c';
		int	z = 70;
		long a = 9999999999l;
		short b = -2000;
		float c = 2.59f;
		double d = 4444444444444444444.56666;
		boolean	e = true;
		byte f = -100;
		
		System.out.println("enter the values of"+x);
		System.out.println(y);
		System.out.println(z);
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);
		System.out.println(f);
	}
}
