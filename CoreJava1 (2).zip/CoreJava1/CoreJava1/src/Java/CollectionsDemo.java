package Java;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

public class CollectionsDemo {
	public static void main(String[] args) {
	List<String> employeeList = new ArrayList();
	employeeList.add("Venkatesh");
	employeeList.add("Mohanraj");
	employeeList.add("Venkatesh");
	
	System.out.println(employeeList);
	
	Collections.sort(employeeList);			//Sorted List
	System.out.println( employeeList);

	Collections.reverse(employeeList);		//Reverse List
	System.out.println( employeeList);
	
	Collections.shuffle(employeeList);		//Shuffled List
	System.out.println( employeeList);
	
	System.out.println(Collections.frequency(employeeList,"Venkatesh"));
	//Checking occurance of Venkatesh

	}
}
		