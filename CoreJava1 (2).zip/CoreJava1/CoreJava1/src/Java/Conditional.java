package Java;

public class Conditional {

	public static void main(String[] args) {
		String classification ="Employee";
		String Teacher = "Language";
		int marks = 80;
		String result;
		int a =10;
		int b =5;
		
		if (a==b)
		{
			System.out.println("Pass");
		}
		else
		{
			System.out.println("Fail");
		}
		
		if (classification == "Student")    //A>B
		{
			if (marks > 70)					//A>C
				System.out.println("Pass");	  //True
			else
				System.out.println("Fail");	
		}
		else
		{   if (Teacher == "Language")  
				System.out.println("Yes");
			else
				System.out.println("No");
		}
			
	
		/*if (marks > 70)
		{	System.out.println("Pass");		}//True
		else
		{	System.out.println("Fail");		}//False*/
		
		/*result = (marks > 70) ? "Pass" : "Fail"; //Ternary Operator
		System.out.println(result);*/	
	}
}
