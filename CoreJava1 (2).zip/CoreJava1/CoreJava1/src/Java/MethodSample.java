package Java;

public class MethodSample {
	
	public static void main(String[] args) {
		System.out.println("Calling Method...");
		
		printingSample();
		
		System.out.println("Back from Method...");
	}
	
	public static void printingSample()
	{	
		System.out.println("From Method...");
	}
}
