package Java;

public class SingleinheritanceSampleB extends SingleinheritanceSampleA {
	public static void main(String[] args) {
	 SingleinheritanceSampleB obj = new SingleinheritanceSampleB();
	    obj.methodA(); //calling super class
	    obj.methodB(); //calling sub class
	}
		
	public void methodB()
	{
	     System.out.println("Child class");
	}
}
