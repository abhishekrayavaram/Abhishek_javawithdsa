package Java;

class Employee{  
	   int empid;					  
	   String empname;  
	   static String organization ="XYZ";		//static variable  
	   Employee(int r, String n)				//constructor
	   {  
	   empid = r;  
	   empname = n;  
	   }  
	   void display (){System.out.println(empid+" "+empname+" "+organization);}  
	}  
	
	public class Staticexample{  
	 public static void main(String args[]){  
	 Employee e1 = new Employee(111,"Karan");  
	 Employee e2 = new Employee(222,"Aryan");  
	 //we can change the college of all objects by the single line of code  
	 //Employee.organization="ABC";  
	 e1.display();  
	 e2.display();  
	 }  
	}  