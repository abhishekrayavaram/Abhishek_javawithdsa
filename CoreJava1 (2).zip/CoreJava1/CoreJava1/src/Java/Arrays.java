package Java;

public class Arrays {
	public static void main(String[] args) {
		
		String employeeName[] = {"Vivek", "Hari"};
	
		int employeeId[] = new int[2];
		employeeId[0] = 10;
		employeeId[1] = 20;
		System.out.println("Hi"+" "+"Welcome");
		System.out.println(employeeName[0]+ " " +employeeId[0]);
		System.out.println(employeeName[1]+ " " +employeeId[1]);	
	}
}
