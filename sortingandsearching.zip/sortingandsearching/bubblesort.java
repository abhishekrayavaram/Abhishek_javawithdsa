package sortingandsearching;

public class bubblesort {
	static int array[]= {2,1,6,5,4};

	public static void main(String[] args) {
		int length=array.length;
		System.out.println("unsorted array");
		for(int i=0;i<length;i++) {
			System.out.println(array[i]);
		}
		System.out.println("unsorted array");
		bubblesort(array,length);
		// TODO Auto-generated method stub
	}
	public static void bubblesort(int array[],int length) {
		for(int i=0;i<length-1;i++) {
			for(int j=i+1;j<length;j++) {
				int temp;
				if(array[i]>array[j]) {
					temp=array[i];
					array[i]=array[j];
					array[j]=temp;
				}
			}
		}
		for(int i=0;i<length;i++) {
			System.out.println(array[i]);
		}
	}

}
