package sortingandsearching;

import java.util.ArrayList;
import java.util.List;

public class recursivedeepdrive {

    public static void main(String[] args) {
        int[] nums = {1, 2, 3};
        List<List<Integer>> result = new ArrayList<>();
        generatesubsets(0, nums, new ArrayList<>(), result);

        System.out.println("all subsets:");
        for (List<Integer> subset : result) {
            System.out.println(subset);
        }
    }

    static void generatesubsets(int index, int[] nums, List<Integer> current, List<List<Integer>> result) {
        if (index == nums.length) {
            result.add(new ArrayList<>(current));
            return;
        }

     
        current.add(nums[index]);
        generatesubsets(index + 1, nums, current, result);

 
        current.remove(current.size() - 1);

        
        generatesubsets(index + 1, nums, current, result);
    }
}

