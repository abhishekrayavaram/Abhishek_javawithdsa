package JavaPracticeProgram;

public class Nestedif {

	public static void main(String[] args) {
		int a=100;
		int b=50;
		if(a<=b)
		{
			System.out.println("the statement is correct");// TODO Auto-generated method stub
		}
		if(a==b)
		{
			System.out.println("true");
		}
		else
		{
			System.out.println("the statement is incorrect");
		}

	}

}
