package JavaPracticeProgram;

public class IF_ELSE_IF {

    public static void main(String[] args) {
        // Correctly declare the variable and initialize with a string value
        String name = "man"; // Use double quotes to define a string

        // Use .equals() for string comparison
        if (name.equals("man")) { 
            System.out.println("man");
        } else if (name.equals("car")) { 
            System.out.println("car");
        } else if (name.equals("bike")) { 
            System.out.println("bike");
        } else {
            System.out.println("none");
        }
    }
}
