package JavaPracticeProgram;

public class Arithematiccalculation {

	public static void main(String[] args) {
		int a,b,c,d,e,f;
		a=20;
		b=10;
		c=a+b;
		d=a-b;
		e=a*b;
		f=a/b;
		System.out.println("enter the value of c is addition:"+c);
		System.out.println("enter the value of d is subtaction:"+d);
		System.out.println("enter the value of e is multiplication:"+e);
		System.out.println("enter the value of f is division:"+f);
		// TODO Auto-generated method stub

	}

}
