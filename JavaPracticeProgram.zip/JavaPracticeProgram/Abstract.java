package JavaPracticeProgram;

abstract class Animal {
    abstract void sound();  
}

abstract class Dog extends Animal {
    void sound() {
        System.out.println("Dog barks");
    }
}

class Bulldog extends Dog {

}

public class Abstract {
    public static void main(String[] args) {
     
        Animal obj = new Bulldog();  
        obj.sound();  
    }
}

