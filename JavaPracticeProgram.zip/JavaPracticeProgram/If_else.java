package JavaPracticeProgram;

public class If_else {

	public static void main(String[] args) {
	int a=100;
	int b=50;
	if(a==b)
	{
		System.out.println("number is equal");
	}
	else
	{
		System.out.println("number is un equal");// TODO Auto-generated method stub
	}

	}

}
