package JavaPracticeProgram;

class MyExceptionExample {
    void method() throws Exception {
        int a = 50 / 0;  // This will throw ArithmeticException
        System.out.println(a);
    }
}

public class Exceptiontest {
    public static void main(String args[]) {
        try {
            MyExceptionExample obj = new MyExceptionExample();
            obj.method();
        } catch (Exception e) {
            System.out.println("exception handled");
        }
        System.out.println("inside main function");
    }
}

