package JavaPracticeProgram;

public class Encapsulation {
    private String name;
    public void setname(String name) {
        this.name = name;
    }
    public String getname() {
        return name;
    }
    public static void main(String[] args) {
        Encapsulation obj = new Encapsulation();
        obj.setname("baba");
        System.out.println("name: " + obj.getname());
    }
}
