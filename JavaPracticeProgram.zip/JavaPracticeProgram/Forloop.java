package JavaPracticeProgram;

public class Forloop {

	public static void main(String[] args) {
		 int i;
		 i=0;
		 for(i=0;i<=10;i++)
			 System.out.println(i);// TODO Auto-generated method stub

	}

}