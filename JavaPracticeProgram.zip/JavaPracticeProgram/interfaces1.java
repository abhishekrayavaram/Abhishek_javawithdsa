package JavaPracticeProgram;

public interface interfaces1 {
	void print();
	void print1();

}
