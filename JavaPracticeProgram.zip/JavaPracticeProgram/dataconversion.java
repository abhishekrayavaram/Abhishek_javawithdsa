package JavaPracticeProgram;

public class dataconversion {

	public static void main(String[] args) {
		float a=10.23452f;
	     double b=a;
		System.out.println("double:"+b);// TODO Auto-generated method stub

	}

}
