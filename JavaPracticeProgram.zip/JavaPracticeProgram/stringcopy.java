package JavaPracticeProgram;

public class stringcopy {

	public static void main(String[] args) {
		String originalstring="bramhi";
		String copiedstring1=originalstring;// TODO Auto-generated method stub
        System.out.println(copiedstring1);
        System.out.println(copiedstring1.length());
	}

}
