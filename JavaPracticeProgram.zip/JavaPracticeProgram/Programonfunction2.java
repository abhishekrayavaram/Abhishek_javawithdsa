package JavaPracticeProgram;

public class Programonfunction2 {

    public static void main(String[] args) {
        int a, b, c, d;
        a = 20;
        b = 30;
        
        // Using the add() and sub() methods
        c = add(a, b);
        d = sub(a, b);
        
        System.out.println("c is addition: " + c);
        System.out.println("d is subtraction: " + d);
    }

    // Correctly defined methods
    public static int add(int a, int b) {
        return a + b;
    }

    public static int sub(int a, int b) {
        return a - b;
    }
}

