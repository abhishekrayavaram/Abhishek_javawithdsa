package JavaPracticeProgram;

public class datatypes {

	public static void main(String[] args) {
	 int a=10;
	 System.out.println(a);
	 short b= 2000;
	 System.out.println(b);
	 long c= 237010444l;
	 System.out.println(c);
	 float d=1.244f;
	 System.out.println(d);
	 double e=1.2222222;
	 System.out.println(e);
	 // TODO Auto-generated method stub

	}

}
