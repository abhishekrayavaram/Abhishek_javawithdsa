package JavaPracticeProgram;

public class Details {

	public static void main(String[] args) {
	String name = "baba";
	 System.out.println("hello"+name);
	long rollno = 8019400000l;
	System.out.println("rollno"+rollno);// TODO Auto-generated method stub

	}

}
