package JavaPracticeProgram;

public class Try_catch {

	public static void main(String[] args) {
	try {
	int a=50/2;
	System.out.println(a);// TODO Auto-generated method stub
	}finally {
		System.out.println("successfull");
	}

}
}
