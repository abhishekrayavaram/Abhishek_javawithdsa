package JavaPracticeProgram;

public class Ifcondition {

	public static void main(String[] args) {
		int i=20;
		if(i>10)
			System.out.println("number is even");// TODO Auto-generated method stub

	}

}
