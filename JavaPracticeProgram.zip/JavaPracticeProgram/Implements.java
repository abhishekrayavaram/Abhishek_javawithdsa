package JavaPracticeProgram;

public class Implements implements interfaces1 {
	public void print() {
		System.out.println("hello welcome");
	}
	public void print1()
	{
		System.out.println("to crt program");
	}
}
