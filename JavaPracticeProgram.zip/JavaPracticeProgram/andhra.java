package JavaPracticeProgram;

public class andhra extends rbi {
	 public float getrateofinterest()
	{
		return 8.4f;
	}

}
