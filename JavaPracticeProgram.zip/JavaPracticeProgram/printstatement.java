package JavaPracticeProgram;

public class printstatement {

	public static void main(String[] args) {
	System.out.println("hello welcome");	// TODO Auto-generated method stub

	}

}
