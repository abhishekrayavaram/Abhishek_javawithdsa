package JavaPracticeProgram;

public class typecasting {

	public static void main(String[] args) {
		float a=10;
		int b=(int)a;
		System.out.println("short:"+b);// TODO Auto-generated method stub

	}

}
