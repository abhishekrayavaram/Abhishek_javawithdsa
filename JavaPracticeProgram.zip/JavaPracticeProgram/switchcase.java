package JavaPracticeProgram;

public class switchcase {

	public static void main(String[] args) {
	int a,b,c;
	a=20;
	b=30;
	c=a+b;
	System.out.println("c"+c);
	switch(c) {
	case 1:
		System.out.println("c=10");
		break;
	case 2:
	    System.out.println("c=20");
	    break;
	case 3:
		System.out.println("c=50");
		break;
	default:
		System.out.println("none");
		break;
	}
	// TODO Auto-generated method stub

	}

}
