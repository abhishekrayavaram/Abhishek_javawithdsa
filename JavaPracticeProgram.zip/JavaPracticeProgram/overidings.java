package JavaPracticeProgram;

class pant {
	void run() {
		System.out.println("pant");
	}
}
class overidings extends pant{
	void run()
	{
		System.out.println("again and again use");
		}
	public static void main(String args[]) {
		overidings obj=new overidings();
		obj.run();
		pant obj1=new pant();
		obj1.run();
	}
}