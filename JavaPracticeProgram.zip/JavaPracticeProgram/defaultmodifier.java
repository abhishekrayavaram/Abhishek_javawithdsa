package JavaPracticeProgram;

class defaultmodifier {

	public static void main(String[] args) {
		int a,b,c;
		a=10;
		b=20;
		c=a+b;
		System.out.println("c="+c);// TODO Auto-generated method stub

	}

}
