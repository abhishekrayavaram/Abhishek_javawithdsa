package JavaPracticeProgram;

public class Try {

	public static void main(String[] args) {
		try{
			int a=50/0;
			System.out.println(a);// TODO Auto-generated method stub
		}
		catch(ArithmeticException e)
		{
			System.out.println(e);
			System.out.println("can't divided by zero");
		}
	 System.out.println("completed successfully");
		

	}

}
