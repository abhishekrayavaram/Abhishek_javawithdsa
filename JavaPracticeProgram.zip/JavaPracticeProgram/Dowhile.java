package JavaPracticeProgram;

public class Dowhile {

	public static void main(String[] args) {
		int i=0;
		do
		{
			System.out.println("hello world");
			i=i+1;// TODO Auto-generated method stub
		}while(i<5);
}
}