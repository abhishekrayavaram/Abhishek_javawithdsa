package JavaPracticeProgram;

public class stringcomparision {

	public static void main(String[] args) {
		String s1="bramhaiahachari";
		String s2="bramanya";
		System.out.println(s1.compareTo(s2));// TODO Auto-generated method stub

	}

}
