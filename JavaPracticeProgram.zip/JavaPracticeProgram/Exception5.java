package JavaPracticeProgram;

import java.util.Scanner;

public class Exception5 {

 static void validate(int employeeAge)
  {
	 if(employeeAge<=20)
		 throw new ArithmeticException("notvalid");
	 else
		 System.out.println("welcome to cts");		 
		 
		// TODO Auto-generated method stub

	}
 public static void main(String args[]) {
	 Scanner sc=new Scanner(System.in);
	 System.out.println("enter your age:");
	 int employeeAge=sc.nextInt();
	 try {
		 validate(employeeAge);
	 }
	 catch(Exception e)
	 {
		 System.out.println(e);
	 }
	 System.out.println("execution over");
 }

}
