package JavaPracticeProgram;

import java.util.Scanner; 

public class scanerstatement {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);// TODO Auto-generated method stub
		System.out.println("enter the name");
		String name= sc.next();
		System.out.println("name:"+name);
	}

}
