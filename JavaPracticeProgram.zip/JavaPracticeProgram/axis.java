package JavaPracticeProgram;

public class axis extends rbi {
	public float  getrateofinterest()
	{
		return 7.3f;
	}

}
