package JavaPracticeProgram;

public class Encapsulation2 
{

	public static void main(String[] args) 
	{
		Encapsulation obj = new Encapsulation();
	    
		obj.setname("Vivek");
	    System.out.print("Name : " + obj.getname());  //vivek
	}

}
