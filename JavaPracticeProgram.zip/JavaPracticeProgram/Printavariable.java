package JavaPracticeProgram;

public class Printavariable {

	public static void main(String[] args) {
		int a=20;
		int b=30;
		System.out.println("a"+a);
		System.out.println("b"+b);// TODO Auto-generated method stub

	}

}
