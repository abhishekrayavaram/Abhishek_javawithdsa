package JavaPracticeProgram;

public class Whileloop {

	public static void main(String[] args) {
		int i=0;
		while(i<5)
		{
			System.out.println(0);
		     i++;// TODO Auto-generated method stub
		}
	}

}
