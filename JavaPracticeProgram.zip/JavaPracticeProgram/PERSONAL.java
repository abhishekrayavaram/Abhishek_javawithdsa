package JavaPracticeProgram;

public class PERSONAL {

	public static void main(String[] args) {
	System.out.println("name:machina devid");
	System.out.println("branch:ece");
	System.out.println("roll no:23701a0444");
	System.out.println("section:a");
	System.out.println("phone no:8019400000");
	System.out.println("village:eguvapalli");
	System.out.println("chitvel");
	System.out.println("branch:ece");
	// TODO Auto-generated method stub

	}

}
