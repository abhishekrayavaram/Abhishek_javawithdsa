package JavaPracticeProgram;

public class kotak extends rbi {

	
	
}
