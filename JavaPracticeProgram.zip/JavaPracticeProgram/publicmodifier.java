package JavaPracticeProgram;

public class publicmodifier {

	public static void main(String[] args) {
		int a,b,c;
		a=20;
		b=30;
		c=a+b;
		System.out.println("c="+c);// TODO Auto-generated method stub

	}

}
