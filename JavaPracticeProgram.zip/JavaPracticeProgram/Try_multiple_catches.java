package JavaPracticeProgram;


public class Try_multiple_catches {

	public static void main(String[] args) {
		try{
			int a[]=new int[5];
			a[6]=30;// TODO Auto-generated method stub
		}
 catch(ArithmeticException e)
		{
	 System.out.println("arithematic exception occurs");
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("array index out of bounds exception");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		System.out.println("exception handled");
	}

}
