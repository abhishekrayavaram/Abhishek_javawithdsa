package JavaPracticeProgram;

public class main {

	public static void main(String[] args) {
		Implements obj =new Implements();
		obj.print();
		obj.print1(); // TODO Auto-generated method stub

	}

}
