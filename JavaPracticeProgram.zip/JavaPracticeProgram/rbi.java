package JavaPracticeProgram;


 public class rbi {
	 public float  getrateofinterest()
	 {
		 return 0;
	 }

}
